#include "common.hpp"
#include "vector"
#include "map"
#include "limits"
//#include "omp.h"
#include "lbfgs.h"
#include "sys/time.h"

#include "language.hpp"
using namespace std;

inline double square(double x) //简单函数使用内联函数定义，减少调用函数开销(类似于define)
		{
	return x * x;
}

inline double dsquare(double x) {
	return 2 * x;
}

double clock_() {
	timeval tim;
	gettimeofday(&tim, NULL);
	return tim.tv_sec + (tim.tv_usec / 1000000.0);
}

// 写入数据
void topicCorpus::writeData(FILE* f, vote* v) {
	fprintf(f, "%d %d %f %lu ", v->user, v->item, v->value, v->words.size());
	for (int i = 0; i < v->words.size(); i++) {
		fprintf(f, "%d ", v->words[i]);
	}
	fprintf(f, "\n");
}

// 载入数据
void topicCorpus::loadVotes(std::string fn, std::vector<vote*> V) {
	std::string line;
	vote* v;
	int nw;
	int word;
	ifstream in(fn.c_str());
	while (std::getline(in, line)) {
		std::stringstream ss(line);
		v = new vote();
		ss >> v->user >> v->item >> v->value >> nw;
		for (int i = 0; i < nw; i++) {
			ss >> word;
			v->words.push_back(word);
		}
		V.push_back(v);
	}
	in.close();
}
void topicCorpus::loadVotes_train(std::string fn, std::vector<vote*> V,
		int domain) {
	std::string line;
	vote* v;
	int nw;
	int word;
	ifstream in(fn.c_str());
	while (std::getline(in, line)) {
		std::stringstream ss(line);
		v = new vote();
		ss >> v->user >> v->item >> v->value >> nw;
		for (int i = 0; i < nw; i++) {
			ss >> word;
			v->words.push_back(word);
		}
		V.push_back(v);
		if (domain == 1) {
			trainVotesPerUser[v->user].push_back(v);
			trainVotesPerBeer[v->item].push_back(v);
			if (nTrainingPerUser.find(v->user) == nTrainingPerUser.end())
				nTrainingPerUser[v->user] = 0;
			if (nTrainingPerBeer.find(v->item) == nTrainingPerBeer.end())
				nTrainingPerBeer[v->item] = 0;
			nTrainingPerUser[v->user]++;
			nTrainingPerBeer[v->item]++;
		} else {
			trainVotesPerUser1[v->user].push_back(v);
			trainVotesPerBeer1[v->item].push_back(v);
			if (nTrainingPerUser1.find(v->user) == nTrainingPerUser1.end())
				nTrainingPerUser1[v->user] = 0;
			if (nTrainingPerBeer1.find(v->item) == nTrainingPerBeer1.end())
				nTrainingPerBeer1[v->item] = 0;
			nTrainingPerUser1[v->user]++;
			nTrainingPerBeer1[v->item]++;
		}
	}
	in.close();
}
void topicCorpus::loadVotes_set(std::string fn, std::set<vote*> V) {
	std::string line;
	vote* v;
	int nw;
	int word;
	ifstream in(fn.c_str());
	while (std::getline(in, line)) {
		std::stringstream ss(line);
		v = new vote();
		ss >> v->user >> v->item >> v->value >> nw;
		for (int i = 0; i < nw; i++) {
			ss >> word;
			v->words.push_back(word);
		}
		V.insert(v);
	}
	in.close();
}

/*
 * matrix vector solve using blas
 *
 */
void topicCorpus::matrix_vector_solve(const gsl_matrix* m, const gsl_vector* b,   //K,u,x x是alpha beta
		gsl_vector* v) {
	gsl_matrix *lu;
	gsl_permutation* p;
	int signum;

	p = gsl_permutation_alloc(m->size1);
	lu = gsl_matrix_alloc(m->size1, m->size2);
	gsl_matrix_memcpy(lu, m);
	gsl_linalg_LU_decomp(lu, p, &signum);
	gsl_linalg_LU_solve(lu, p, b, v);
	gsl_matrix_free(lu);
	gsl_permutation_free(p);
}

/*
 * v1和v2表示在commonUser当中的映射
 */
double topicCorpus::computeK(int v1, int v2, int domain) {
	double res = 0;
	int u1, u2;
	if (domain == 1) {
		u1 = commonUserId[v1].first, u2 = commonUserId[v2].first;
		for (int i = 0; i < K; i++) {
			res += square(gamma_user[u1][i] - gamma_user[u2][i]);
//			res += gamma_user[u1][i] * gamma_user[u2][i];
		}
	} else {
		u1 = commonUserId[v1].second, u2 = commonUserId[v2].second;
		for (int i = 0; i < K; i++)
			res += square(gamma_user1[u1][i] - gamma_user1[u2][i]);
//			res += gamma_user1[u1][i] * gamma_user1[u2][i];
	}
	res = exp(res / sigma_square);
//	printf("res:%f,u1:%f,u2:%f\n", res, gamma_user[u1][1], gamma_user[u2][1]);
	return res;
}

void topicCorpus::setAlphaBeta(gsl_vector* x, int i, int domain){
	if (domain == 1) {
		gsl_vector_set(BETA, i, gsl_vector_get(x, 0));
		for (int u = 0; u < nCommon; u++) {
			gsl_matrix_set(ALPHA, u, i, gsl_vector_get(x, u + 1));
		}
	}else{
		gsl_vector_set(BETA1, i, gsl_vector_get(x, 0));
		for (int u = 0; u < nCommon; u++) {
			gsl_matrix_set(ALPHA1, u, i, gsl_vector_get(x, u + 1));
		}
	}
}

/*
 * 用户u映射到另一个域的u'在维度i上的误差，u指commonUser中的序号
 */
double topicCorpus::mapFunErr(int u, int i, int domain) {
	double res = 0;
	if (domain == 1) { // u1->u2的映射
		double fi = 0;
		for (int b = 0; b < nCommon; b++) {
			fi += gsl_matrix_get(ALPHA1, b, i) * computeK(u, b, 1)
					+ gsl_vector_get(BETA1, i);
		}
		res += square(fi - gamma_user1[commonUserId[u].second][i]);
	} else {	// u2->u1
		double gi = 0;
		for (int b = 0; b < nCommon; b++) {
			gi += gsl_matrix_get(ALPHA, b, i) * computeK(u, b, 2)
					+ gsl_vector_get(BETA, i);
		}
		res += square(gi - gamma_user[commonUserId[u].first][i]);
	}
	return res;
}

double topicCorpus::dmapFunErr(int u, int i, int domain) {
	double res = 0;
	if (domain == 1) { // u1->u2的映射
		double fi = 0;
		for (int b = 0; b < nCommon; b++) {
			fi += gsl_matrix_get(ALPHA, b, i) * computeK(u, b, 2)
					+ gsl_vector_get(BETA, i);
		}
		res += gamma_user[commonUserId[u].first][i] - fi;
	} else {	// u2->u1
		double gi = 0;
		for (int b = 0; b < nCommon; b++) {
			gi += gsl_matrix_get(ALPHA1, b, i) * computeK(u, b, 1)
					+ gsl_vector_get(BETA1, i);
		}
		res += gamma_user1[commonUserId[u].second][i] - gi;
	}
	return res;
}

// 更新映射函数参数
void topicCorpus::updateMapPara(){
	gsl_vector* x = gsl_vector_alloc(nCommon + 1);
	gsl_vector* u = gsl_vector_alloc(nCommon + 1);
	gsl_vector_set_zero(u);
	//sd
	gsl_vector* x1 = gsl_vector_alloc(nCommon + 1);
	gsl_vector* u1 = gsl_vector_alloc(nCommon + 1);
	gsl_vector_set_zero(u1);
	int i, j;
	// 更新K_map
	for (i = 1; i < K_map->size1; i++)
		for (j = 1; j < K_map->size2; j++){
			double tmp = computeK(i - 1, j - 1, 1);
			if (i == j)
				tmp += 1.0 / gamma_map;
			gsl_matrix_set(K_map, i, j, tmp);
		}
	for (i = 1; i < K_map1->size1; i++)
		for (j = 1; j < K_map1->size2; j++){
			double tmp = computeK(i - 1, j - 1, 2);
			if (i == j)
				tmp += 1.0 / gamma_map;
			gsl_matrix_set(K_map1, i, j, tmp);
		}
//	for (i = 0; i < K_map->size1; i++)
//		for (j = 0; j < K_map->size2; j++)
//			printf("K(%d,%d) = %f\n", i, j, gsl_matrix_get(K_map, i, j));

//	gsl_matrix_set_identity(K_map);
//	gsl_matrix_set_identity(K_map1);

	//构造U并更新映射函数参数
	for (i = 0; i < K; i++) {
		for (j = 0; j < nCommon; j++) {
			gsl_vector_set(u, j + 1, gamma_user[commonUserId[j].first][i]);
			gsl_vector_set(u1, j + 1, gamma_user1[commonUserId[j].second][i]);
		}
		matrix_vector_solve(K_map, u, x);
		matrix_vector_solve(K_map1, u1, x1);
		setAlphaBeta(x, i, 1);
		setAlphaBeta(x1, i, 2);
	}
}

/// Recover all parameters from a vector (g)
int topicCorpus::getG(double* g, double** alpha, double** kappa,
		double** alpha1, double** kappa1, double** beta_user,
		double** beta_beer, double** beta_user1, double** beta_beer1,
		double*** gamma_user, double*** gamma_beer, double*** topicWords,
		double*** gamma_user1, double*** gamma_beer1, double*** topicWords1,
		bool init) {
	if (init) {
		*gamma_user = new double*[nUsers];
		*gamma_beer = new double*[nBeers];
		*topicWords = new double*[nWords];
		//sd
		*gamma_user1 = new double*[nUsers1];
		*gamma_beer1 = new double*[nBeers1];
		*topicWords1 = new double*[nWords1];
	}

	int ind = 0;
	*alpha = g + ind;
	ind++;
	*kappa = g + ind;
	ind++;
	//sd
	*alpha1 = g + ind;
	ind++;
	*kappa1 = g + ind;
	ind++;

	*beta_user = g + ind;
	ind += nUsers;
	*beta_beer = g + ind;
	ind += nBeers;
	//sd
	*beta_user1 = g + ind;
	ind += nUsers1;
	*beta_beer1 = g + ind;
	ind += nBeers1;

	for (int u = 0; u < nUsers; u++) { // nUsers个用户，每个用户有K维，以下类似
		(*gamma_user)[u] = g + ind;
		ind += K;
	}
	for (int b = 0; b < nBeers; b++) {
		(*gamma_beer)[b] = g + ind;
		ind += K;
	}
	for (int w = 0; w < nWords; w++) {
		(*topicWords)[w] = g + ind;
		ind += K;
	}
	//sd
	for (int u = 0; u < nUsers1; u++) { // nUsers个用户，每个用户有K维，以下类似
		(*gamma_user1)[u] = g + ind;
		ind += K;
	}
	for (int b = 0; b < nBeers1; b++) {
		(*gamma_beer1)[b] = g + ind;
		ind += K;
	}
	for (int w = 0; w < nWords1; w++) {
		(*topicWords1)[w] = g + ind;
		ind += K;
	}

	if (ind != NW) {
		printf("Got incorrect index at line %d\n", __LINE__);
		printf("NW:%d; ind:%d\n", NW, ind);
		exit(1);
	}
	return ind;
}

/// Free parameters
void topicCorpus::clearG(double** alpha, double** kappa, double** alpha1,
		double** kappa1, double** beta_user, double** beta_beer,
		double** beta_user1, double** beta_beer1, double*** gamma_user,
		double*** gamma_beer, double*** topicWords, double*** gamma_user1,
		double*** gamma_beer1, double*** topicWords1) {
	delete[] (*gamma_user);
	delete[] (*gamma_beer);
	delete[] (*topicWords);
	delete[] (*gamma_user1);
	delete[] (*gamma_beer1);
	delete[] (*topicWords1);
}

// Compute energy energy即目标函数的值
static lbfgsfloatval_t evaluate(void *instance, const lbfgsfloatval_t *x,
		lbfgsfloatval_t *g, const int n, const lbfgsfloatval_t step) {
	topicCorpus* ec = (topicCorpus*) instance;

	for (int i = 0; i < ec->NW; i++)
		ec->W[i] = x[i];

	double* grad = new double[ec->NW]; // W所有参数的线性数组，NW参数个数
	for (int i = 0; i < ec->NW; i++)
		grad[i] = 0;
	ec->dl(grad);
	for (int i = 0; i < ec->NW; i++) {
		g[i] = grad[i];
	}
	delete[] grad;

	lbfgsfloatval_t fx = ec->lsq();
	return fx;
}

static int progress(void *instance, const lbfgsfloatval_t *x,
		const lbfgsfloatval_t *g, const lbfgsfloatval_t fx,
		const lbfgsfloatval_t xnorm, const lbfgsfloatval_t gnorm,
		const lbfgsfloatval_t step, int n, int k, int ls) {
	static double gtime = clock_();
	printf(".");
	fflush( stdout);
	double tdiff = clock_();
	gtime = tdiff;
	return 0;
}

/// Predict a particular rating given the current parameter values 论文中公式1
double topicCorpus::prediction(vote* vi, int domain) {
	if (domain == 1) {
		int user = vi->user;
		int beer = vi->item;
		double res = *alpha + beta_user[user] + beta_beer[beer];
		for (int k = 0; k < K; k++)
			res += gamma_user[user][k] * gamma_beer[beer][k];
		return res;
	} else {
		int user = vi->user;
		int beer = vi->item;
		double res = *alpha1 + beta_user1[user] + beta_beer1[beer];
		for (int k = 0; k < K; k++)
			res += gamma_user1[user][k] * gamma_beer1[beer][k];
		return res;
	}
}

/// Compute normalization constant for a particular item
void topicCorpus::topicZ(int beer, double& res, int domain) {
	res = 0;
	if(domain == 1)
		for (int k = 0; k < K; k++)
			res += exp(*kappa * gamma_beer[beer][k]);
	else
		for (int k = 0; k < K; k++)
			res += exp(*kappa1 * gamma_beer1[beer][k]);
}

/// Compute normalization constants for all K topics
void topicCorpus::wordZ(double* res, int domain) {
	if(domain == 1)
		for (int k = 0; k < K; k++) {
			res[k] = 0;
			for (int w = 0; w < nWords; w++)
				res[k] += exp(backgroundWords[w] + topicWords[w][k]);
		}
	else
		for (int k = 0; k < K; k++) {
			res[k] = 0;
			for (int w = 0; w < nWords1; w++){
				res[k] += exp(backgroundWords1[w] + topicWords1[w][k]);
			}
		}
}

/// Update topic assignments for each word. If sample==true, this is done by sampling, otherwise it's done by maximum likelihood (which doesn't work very well)
void topicCorpus::updateTopics(bool sample) {
	double updateStart = clock_();

	for (int x = 0; x < (int) trainVotes.size(); x++) {
		if (x > 0 and x % 100000 == 0) {
			printf(".");
			fflush(stdout);
		}
		vote* vi = trainVotes[x];
		int beer = vi->item;

		int* topics = wordTopics[vi];

		for (int wp = 0; wp < (int) vi->words.size(); wp++) { // For each word position
			int wi = vi->words[wp]; // The word
			double* topicScores = new double[K];
			double topicTotal = 0;
			for (int k = 0; k < K; k++) {
				topicScores[k] = exp(
						*kappa * gamma_beer[beer][k] + backgroundWords[wi]
								+ topicWords[wi][k]);
				topicTotal += topicScores[k];
			}

			for (int k = 0; k < K; k++)
				topicScores[k] /= topicTotal;

			int newTopic = 0;
			if (sample) {
				double x = rand() * 1.0 / (1.0 + RAND_MAX);
				while (true) {
					x -= topicScores[newTopic];
					if (x < 0)
						break;
					newTopic++;
				}
			} else {
				double bestScore = -numeric_limits<double>::max();
				for (int k = 0; k < K; k++)
					if (topicScores[k] > bestScore) {
						bestScore = topicScores[k];
						newTopic = k;
					}
			}
			delete[] topicScores;

			if (newTopic != topics[wp]) { // Update topic counts if the topic for this word position changed
				{
					int t = topics[wp];
					wordTopicCounts[wi][t]--;
					wordTopicCounts[wi][newTopic]++;
					topicCounts[t]--;
					topicCounts[newTopic]++;
					beerTopicCounts[beer][t]--;
					beerTopicCounts[beer][newTopic]++;
					topics[wp] = newTopic;
				}
			}
		}
	}
	//sd
	if(flag){
		for (int x = 0; x < (int) trainVotes1.size(); x++) {
			if (x > 0 and x % 100000 == 0) {
				printf(".");
				fflush(stdout);
			}
			vote* vi = trainVotes1[x];
			int beer = vi->item;

			int* topics = wordTopics1[vi];

			for (int wp = 0; wp < (int) vi->words.size(); wp++) { // For each word position
				int wi = vi->words[wp]; // The word
				double* topicScores = new double[K];
				double topicTotal = 0;
				for (int k = 0; k < K; k++) {
					topicScores[k] = exp(
							*kappa1 * gamma_beer1[beer][k]
									+ backgroundWords1[wi]
									+ topicWords1[wi][k]);
					topicTotal += topicScores[k];
				}

				for (int k = 0; k < K; k++)
					topicScores[k] /= topicTotal;

				int newTopic = 0;
				if (sample) {
					double x = rand() * 1.0 / (1.0 + RAND_MAX);
					while (true) {
						x -= topicScores[newTopic];
						if (x < 0)
							break;
						newTopic++;
					}
				} else {
					double bestScore = -numeric_limits<double>::max();
					for (int k = 0; k < K; k++)
						if (topicScores[k] > bestScore) {
							bestScore = topicScores[k];
							newTopic = k;
						}
				}
				delete[] topicScores;

				if (newTopic != topics[wp]) { // Update topic counts if the topic for this word position changed
					{
						int t = topics[wp];
						wordTopicCounts1[wi][t]--;
						wordTopicCounts1[wi][newTopic]++;
						topicCounts1[t]--;
						topicCounts1[newTopic]++;
						beerTopicCounts1[beer][t]--;
						beerTopicCounts1[beer][newTopic]++;
						topics[wp] = newTopic;
					}
				}
			}
		}
	}
	printf("\n");
}

/// Derivative of the energy function
void topicCorpus::dl(double* grad) {
	double dlStart = clock_();

	for (int w = 0; w < NW; w++)
		grad[w] = 0;

	double* dalpha;
	double* dkappa;
	double* dbeta_user;
	double* dbeta_beer;
	double** dgamma_user;
	double** dgamma_beer;
	double** dtopicWords;
	//sd
	double* dalpha1;
	double* dkappa1;
	double* dbeta_user1;
	double* dbeta_beer1;
	double** dgamma_user1;
	double** dgamma_beer1;
	double** dtopicWords1;

	getG(grad, &(dalpha), &(dkappa), &(dalpha1), &(dkappa1), &(dbeta_user),
			&(dbeta_beer), &(dbeta_user1), &(dbeta_beer1), &(dgamma_user),
			&(dgamma_beer), &(dtopicWords), &(dgamma_user1), &(dgamma_beer1),
			&(dtopicWords1), true);

	// 添加跨域项
	if (flag) {
//#pragma omp parallel for
		for (int u = 0; u < nCommon; u++) {
			for (int k = 0; k < K; k++) {
				double tmp = dmapFunErr(u, k, 2);
				dgamma_user1[commonUserId[u].second][k] += global_lambda * tmp;
				tmp = dmapFunErr(u, k, 1);
				dgamma_user[commonUserId[u].first][k] += global_lambda * tmp;
			}
		}
	}

	double da = 0;
//#pragma omp parallel for reduction(+:da) // omp编译器指令
	for (int u = 0; u < nUsers; u++) {
		for (vector<vote*>::iterator it = trainVotesPerUser[u].begin();
				it != trainVotesPerUser[u].end(); it++) { // 将所有物品累加
			vote* vi = *it;
			double p = prediction(vi, 1);
			double dl = dsquare(p - vi->value);

			da += dl;
			dbeta_user[u] += dl;
			for (int k = 0; k < K; k++){
				dgamma_user[u][k] += (1 - global_lambda) * dl
						* gamma_beer[vi->item][k];
			}
		}
	}
	(*dalpha) = da;
	//sd
	if (flag) {
		da = 0;
//#pragma omp parallel for reduction(+:da)
		for (int u = 0; u < nUsers1; u++) {
			for (vector<vote*>::iterator it = trainVotesPerUser1[u].begin();
					it != trainVotesPerUser1[u].end(); it++) { // 将所有物品累加
				vote* vi = *it;
				double p = prediction(vi, 2);
				double dl = dsquare(p - vi->value);

				da += dl;
				dbeta_user1[u] += dl;
				for (int k = 0; k < K; k++)
					dgamma_user1[u][k] += (1 - global_lambda) * dl
							* gamma_beer1[vi->item][k];
			}
		}
		(*dalpha1) = da;
	}

//#pragma omp parallel for
	for (int b = 0; b < nBeers; b++) {
		for (vector<vote*>::iterator it = trainVotesPerBeer[b].begin();
				it != trainVotesPerBeer[b].end(); it++) { // 将所有用户累加
			vote* vi = *it;
			double p = prediction(vi, 1);
			double dl = dsquare(p - vi->value);

			dbeta_beer[b] += dl;
			for (int k = 0; k < K; k++)
				dgamma_beer[b][k] += dl * gamma_user[vi->user][k];
		}
	}
	//sd
	if (flag) {
//#pragma omp parallel for
		for (int b = 0; b < nBeers1; b++) {
			for (vector<vote*>::iterator it = trainVotesPerBeer1[b].begin();
					it != trainVotesPerBeer1[b].end(); it++) { // 将所有用户累加
				vote* vi = *it;
				double p = prediction(vi, 2);
				double dl = dsquare(p - vi->value);

				dbeta_beer1[b] += dl;
				for (int k = 0; k < K; k++)
					dgamma_beer1[b][k] += dl * gamma_user1[vi->user][k];
			}
		}
	}

	double dk = 0;
//#pragma omp parallel for reduction(+:dk)
	for (int b = 0; b < nBeers; b++) {
		double tZ;
		topicZ(b, tZ, 1);

		for (int k = 0; k < K; k++) {
			double q =-lambda * (beerTopicCounts[b][k] - beerWords[b] * exp(*kappa * gamma_beer[b][k]) / tZ);
			dgamma_beer[b][k] += *kappa * q;
			dk += gamma_beer[b][k] * q;
		}
	}
	(*dkappa) = dk;
	//sd
	if(flag){
		dk = 0;
//#pragma omp parallel for reduction(+:dk)
		for (int b = 0; b < nBeers1; b++) {
			double tZ;
			topicZ(b, tZ, 2);

			for (int k = 0; k < K; k++) {
				double q = -lambda1 * (beerTopicCounts1[b][k] - beerWords1[b]
								* exp(*kappa1 * gamma_beer1[b][k]) / tZ);
				dgamma_beer1[b][k] += *kappa1 * q;
				dk += gamma_beer1[b][k] * q;
			}
		}
		(*dkappa1) = dk;
	}

	// Add the derivative of the regularizer
	if (latentReg > 0) {
		for (int u = 0; u < nUsers; u++)
			for (int k = 0; k < K; k++)
				dgamma_user[u][k] += latentReg * dsquare(gamma_user[u][k]);
		for (int b = 0; b < nBeers; b++)
			for (int k = 0; k < K; k++)
				dgamma_beer[b][k] += latentReg * dsquare(gamma_beer[b][k]);
	}
	//sd
	if (latentReg1 > 0 && flag) {
		for (int u = 0; u < nUsers1; u++)
			for (int k = 0; k < K; k++)
				dgamma_user1[u][k] += latentReg1 * dsquare(gamma_user1[u][k]);
		for (int b = 0; b < nBeers1; b++)
			for (int k = 0; k < K; k++)
				dgamma_beer1[b][k] += latentReg1 * dsquare(gamma_beer1[b][k]);
	}

	double* wZ = new double[K];
	wordZ(wZ, 1);
	//sd
	double* wZ1 = new double[K];
	wordZ(wZ1, 2);

//#pragma omp parallel for
	for (int w = 0; w < nWords; w++)
		for (int k = 0; k < K; k++) {
			int twC = wordTopicCounts[w][k];
			double ex = exp(backgroundWords[w] + topicWords[w][k]);
			dtopicWords[w][k] += -lambda * (twC - topicCounts[k] * ex / wZ[k]);
		}
	//sd
	if(flag){
//#pragma omp parallel for
		for (int w = 0; w < nWords1; w++)
			for (int k = 0; k < K; k++) {
				int twC = wordTopicCounts1[w][k];
				double ex = exp(backgroundWords1[w] + topicWords1[w][k]);
				dtopicWords1[w][k] += -lambda1 * (twC - topicCounts1[k] * ex / wZ1[k]);
			}
	}

	delete[] wZ;
	delete[] wZ1;

	clearG(&(dalpha), &(dkappa), &(dalpha1), &(dkappa1), &(dbeta_user),
			&(dbeta_beer), &(dbeta_user1), &(dbeta_beer1), &(dgamma_user),
			&(dgamma_beer), &(dtopicWords), &(dgamma_user1), &(dgamma_beer1),
			&(dtopicWords1));
}

/// Compute the energy according to the least-squares criterion
double topicCorpus::lsq() {
	double lsqStart = clock_();
	double res = 0;

//#pragma omp parallel for reduction(+:res)
	for (int x = 0; x < (int) trainVotes.size(); x++) {
		vote* vi = trainVotes[x];
		res += square(prediction(vi, 1) - vi->value);
	}
	//sd
	if(flag){
//#pragma omp parallel for reduction(+:res)
		for (int x = 0; x < (int) trainVotes1.size(); x++) {
			vote* vi = trainVotes1[x];
			res += square(prediction(vi, 2) - vi->value);
		}
	}

	for (int b = 0; b < nBeers; b++) {
		double tZ;
		topicZ(b, tZ, 1);
		double lZ = log(tZ);

		for (int k = 0; k < K; k++)
			res += -lambda * beerTopicCounts[b][k]
					* (*kappa * gamma_beer[b][k] - lZ);
	}
	//sd
	if(flag){
		for (int b = 0; b < nBeers1; b++) {
			double tZ;
			topicZ(b, tZ, 2);
			double lZ = log(tZ);

			for (int k = 0; k < K; k++)
				res += -lambda1 * beerTopicCounts1[b][k]
						* (*kappa1 * gamma_beer1[b][k] - lZ);
		}
	}

	// Add the regularizer to the energy
	if (latentReg > 0) {
		for (int u = 0; u < nUsers; u++)
			for (int k = 0; k < K; k++)
				res += latentReg * square(gamma_user[u][k]);
		for (int b = 0; b < nBeers; b++)
			for (int k = 0; k < K; k++)
				res += latentReg * square(gamma_beer[b][k]);
	}
	//sd
	if (latentReg1 > 0 && flag) {
		for (int u = 0; u < nUsers1; u++)
			for (int k = 0; k < K; k++)
				res += latentReg1 * square(gamma_user1[u][k]);
		for (int b = 0; b < nBeers1; b++)
			for (int k = 0; k < K; k++)
				res += latentReg1 * square(gamma_beer1[b][k]);
	}

	double* wZ = new double[K];
	wordZ(wZ, 1);
	for (int k = 0; k < K; k++) {
		double lZ = log(wZ[k]);
		for (int w = 0; w < nWords; w++)
			res += -lambda * wordTopicCounts[w][k]
					* (backgroundWords[w] + topicWords[w][k] - lZ);
	}
	delete[] wZ;
	//sd
	if (flag) {
		wZ = new double[K];
		wordZ(wZ, 2);
		for (int k = 0; k < K; k++) {
			double lZ = log(wZ[k]);
			for (int w = 0; w < nWords1; w++)
				res += -lambda1 * wordTopicCounts1[w][k]
						* (backgroundWords1[w] + topicWords1[w][k] - lZ);
		}
		delete[] wZ;
	}

	// 添加跨域项
	if (flag) {
		res *= (1 - global_lambda);
		for (int u = 0; u < nCommon; u++) {
			for (int i = 0; i < K; i++) {
				res += global_lambda * mapFunErr(u, i, 1);
				res += global_lambda * mapFunErr(u, i, 2);
			}
		}
	}

	double lsqEnd = clock_();

	return res;
}

/// Compute the average and the variance
void averageVar(vector<double>& values, double& av, double& var) {
	double sq = 0;
	av = 0;
	for (vector<double>::iterator it = values.begin(); it != values.end();
			it++) {
		av += *it;
		sq += (*it) * (*it);
	}
	av /= values.size();
	sq /= values.size();
	var = sq - av * av;
}



/// Compute the validation and test error (and testing standard error)
void topicCorpus::validTestError(double& train, double& valid, double& test,
		double& testSte, double& train1, double& valid1, double& test1,
		double& testSte1) {
	train = 0;
	valid = 0;
	test = 0;
	testSte = 0;
	//sd
	train1 = 0;
	valid1 = 0;
	test1 = 0;
	testSte1 = 0;

	map<int, vector<double> > errorVsTrainingUser;
	map<int, vector<double> > errorVsTrainingBeer;
	//sd
	map<int, vector<double> > errorVsTrainingUser1;
	map<int, vector<double> > errorVsTrainingBeer1;

	for (vector<vote*>::iterator it = trainVotes.begin();
			it != trainVotes.end(); it++)
		train += square(prediction(*it, 1) - (*it)->value);
	for (vector<vote*>::iterator it = validVotes.begin();
			it != validVotes.end(); it++)
		valid += square(prediction(*it, 1) - (*it)->value);
	for (set<vote*>::iterator it = testVotes.begin(); it != testVotes.end();
			it++) {
		double err = square(prediction(*it, 1) - (*it)->value);
		test += err;
		testSte += err * err;
		if (nTrainingPerUser.find((*it)->user) != nTrainingPerUser.end()) {
			int nu = nTrainingPerUser[(*it)->user];
			if (errorVsTrainingUser.find(nu) == errorVsTrainingUser.end())
				errorVsTrainingUser[nu] = vector<double>();
			errorVsTrainingUser[nu].push_back(err);
		}
		if (nTrainingPerBeer.find((*it)->item) != nTrainingPerBeer.end()) {
			int nb = nTrainingPerBeer[(*it)->item];
			if (errorVsTrainingBeer.find(nb) == errorVsTrainingBeer.end())
				errorVsTrainingBeer[nb] = vector<double>();
			errorVsTrainingBeer[nb].push_back(err);
		}
	}
	//sd
	for (vector<vote*>::iterator it = trainVotes1.begin();
			it != trainVotes1.end(); it++)
		train1 += square(prediction(*it, 2) - (*it)->value);
	for (vector<vote*>::iterator it = validVotes1.begin();
			it != validVotes1.end(); it++)
		valid1 += square(prediction(*it, 2) - (*it)->value);
	for (set<vote*>::iterator it = testVotes1.begin(); it != testVotes1.end();
			it++) {
		double err1 = square(prediction(*it, 2) - (*it)->value);
		test1 += err1;
		testSte1 += err1 * err1;
		if (nTrainingPerUser1.find((*it)->user) != nTrainingPerUser1.end()) {
			int nu = nTrainingPerUser1[(*it)->user];
			if (errorVsTrainingUser1.find(nu) == errorVsTrainingUser1.end())
				errorVsTrainingUser1[nu] = vector<double>();
			errorVsTrainingUser1[nu].push_back(err1);
		}
		if (nTrainingPerBeer1.find((*it)->item) != nTrainingPerBeer1.end()) {
			int nb = nTrainingPerBeer1[(*it)->item];
			if (errorVsTrainingBeer1.find(nb) == errorVsTrainingBeer1.end())
				errorVsTrainingBeer1[nb] = vector<double>();
			errorVsTrainingBeer1[nb].push_back(err1);
		}
	}

	// Standard error
	for (map<int, vector<double> >::iterator it = errorVsTrainingBeer.begin();
			it != errorVsTrainingBeer.end(); it++) {
		if (it->first > 100)
			continue;
		double av, var;
		averageVar(it->second, av, var);
	}
	//sd
	for (map<int, vector<double> >::iterator it = errorVsTrainingBeer1.begin();
			it != errorVsTrainingBeer1.end(); it++) {
		if (it->first > 100)
			continue;
		double av1, var1;
		averageVar(it->second, av1, var1);
	}

	train /= trainVotes.size();
	valid /= validVotes.size();
	test /= testVotes.size();
	testSte /= testVotes.size();
	testSte = sqrt((testSte - test * test) / testVotes.size());
	//sd
	train1 /= trainVotes1.size();
	valid1 /= validVotes1.size();
	test1 /= testVotes1.size();
	testSte1 /= testVotes1.size();
	testSte1 = sqrt((testSte1 - test1 * test1) / testVotes.size());
}


/// Compute MAE
void topicCorpus::validMaeError(double& train, double& valid, double& test,
		double& train1, double& valid1, double& test1) {
	train = 0;
	valid = 0;
	test = 0;
	//sd
	train1 = 0;
	valid1 = 0;
	test1 = 0;

	for (vector<vote*>::iterator it = trainVotes.begin();
			it != trainVotes.end(); it++)
		train += std::abs(prediction(*it, 1) - (*it)->value);
	for (vector<vote*>::iterator it = validVotes.begin();
			it != validVotes.end(); it++)
		valid += std::abs(prediction(*it, 1) - (*it)->value);
	for (set<vote*>::iterator it = testVotes.begin(); it != testVotes.end();
			it++)
		test += std::abs(prediction(*it, 1) - (*it)->value);
	//sd
	for (vector<vote*>::iterator it = trainVotes1.begin();
			it != trainVotes1.end(); it++)
		train1 += std::abs(prediction(*it, 2) - (*it)->value);
	for (vector<vote*>::iterator it = validVotes1.begin();
			it != validVotes1.end(); it++)
		valid1 += std::abs(prediction(*it, 2) - (*it)->value);
	for (set<vote*>::iterator it = testVotes1.begin(); it != testVotes1.end();
			it++) {
		test1 += std::abs(prediction(*it, 2) - (*it)->value);
	}

	train /= trainVotes.size();
	valid /= validVotes.size();
	test /= testVotes.size();
	//sd
	train1 /= trainVotes1.size();
	valid1 /= validVotes1.size();
	test1 /= testVotes1.size();
}


/// Print out the top words for each topic
void topicCorpus::topWords() {
	printf("First Top words for each topic:\n");
	for (int k = 0; k < K; k++) {
		vector<pair<double, int> > bestWords;
		for (int w = 0; w < nWords; w++)
			bestWords.push_back(pair<double, int>(-topicWords[w][k], w));
		sort(bestWords.begin(), bestWords.end());
		for (int w = 0; w < 10; w++) {
			printf("%s (%f) ", corp->idWord[bestWords[w].second].c_str(),
					-bestWords[w].first);
		}
		printf("\n");
	}
	//sd
	printf("\nSecond Top words for each topic:\n");
	for (int k = 0; k < K; k++) {
		vector<pair<double, int> > bestWords1;
		for (int w = 0; w < nWords1; w++)
			bestWords1.push_back(pair<double, int>(-topicWords1[w][k], w));
		sort(bestWords1.begin(), bestWords1.end());
		for (int w = 0; w < 10; w++) {
			printf("%s (%f) ", corp1->idWord[bestWords1[w].second].c_str(),
					-bestWords1[w].first);
		}
		printf("\n");
	}
}

/// Subtract averages from word weights so that each word has average weight zero across all topics (the remaining weight is stored in "backgroundWords")
void topicCorpus::normalizeWordWeights(void) {
	for (int w = 0; w < nWords; w++) {
		double av = 0;
		for (int k = 0; k < K; k++)
			av += topicWords[w][k];
		av /= K;
		for (int k = 0; k < K; k++)
			topicWords[w][k] -= av;
		backgroundWords[w] += av;
	}
	//sd
	if(flag){
		for (int w = 0; w < nWords1; w++) {
			double av1 = 0;
			for (int k = 0; k < K; k++)
				av1 += topicWords1[w][k];
			av1 /= K;
			for (int k = 0; k < K; k++)
				topicWords1[w][k] -= av1;
			backgroundWords1[w] += av1;
		}
	}
}

/// Save a model and predictions to two files
void topicCorpus::save(char* modelPath, char* predictionPath) {
	if (modelPath) {
		FILE* f = fopen_(modelPath, "w");
		if (lambda > 0)
			for (int k = 0; k < K; k++) {
				vector<pair<double, int> > bestWords;
				for (int w = 0; w < nWords; w++)
					bestWords.push_back(
							pair<double, int>(-topicWords[w][k], w));
				sort(bestWords.begin(), bestWords.end());
				for (int w = 0; w < nWords; w++)
					fprintf(f, "%s %f\n",
							corp->idWord[bestWords[w].second].c_str(),
							-bestWords[w].first);
				if (k < K - 1)
					fprintf(f, "\n");
			}
		fclose(f);
	}

	if (predictionPath) {
		FILE* f = fopen_(predictionPath, "w");
		for (vector<vote*>::iterator it = trainVotes.begin();
				it != trainVotes.end(); it++)
			fprintf(f, "%s %s %f %f\n", corp->rUserIds[(*it)->user].c_str(),
					corp->rBeerIds[(*it)->item].c_str(), (*it)->value,
					bestValidPredictions[*it]);
		fprintf(f, "\n");
		for (vector<vote*>::iterator it = validVotes.begin();
				it != validVotes.end(); it++)
			fprintf(f, "%s %s %f %f\n", corp->rUserIds[(*it)->user].c_str(),
					corp->rBeerIds[(*it)->item].c_str(), (*it)->value,
					bestValidPredictions[*it]);
		fprintf(f, "\n");
		for (set<vote*>::iterator it = testVotes.begin(); it != testVotes.end();
				it++)
			fprintf(f, "%s %s %f %f\n", corp->rUserIds[(*it)->user].c_str(),
					corp->rBeerIds[(*it)->item].c_str(), (*it)->value,
					bestValidPredictions[*it]);
		fclose(f);
	}
}

/// Train a model for "emIterations" with "gradIterations" of gradient descent at each step
void topicCorpus::train(int emIterations, int gradIterations) {
	double bestValid = numeric_limits<double>::max();
	double bestValid1 = numeric_limits<double>::max();
	// MAE
	double mae_bestValid = numeric_limits<double>::max();
	double mae_bestValid1 = numeric_limits<double>::max();
	bestTest = numeric_limits<double>::max();
	bestTest1 = numeric_limits<double>::max();
	mae_bestTest = numeric_limits<double>::max();
	mae_bestTest1 = numeric_limits<double>::max();
	for (int emi = 0; emi < emIterations; emi++) {
		printf("\n\n::::::::::::::::::::::%d::::::::::::::::::::::\n\n", emi);
		lbfgsfloatval_t fx = 0;
		lbfgsfloatval_t* x = lbfgs_malloc(NW);
		for (int i = 0; i < NW; i++)
			x[i] = W[i];

		lbfgs_parameter_t param;
		lbfgs_parameter_init(&param);
		param.max_iterations = gradIterations;
		param.epsilon = 1e-2;
		param.delta = 1e-2;
		lbfgs(NW, x, &fx, evaluate, progress, (void*) this, &param);
		printf("\nenergy after gradient step = %f\n", fx);
		lbfgs_free(x);

		//开始迭代另一个域
		if (emi >= 10)
			flag = true;

		if (lambda > 0 && lambda1 > 0) {
			updateTopics(true);
			normalizeWordWeights();
			topWords();
			if (flag)
				updateMapPara();
		}

		double train, valid, test, testSte, train1, valid1, test1, testSte1;
		validTestError(train, valid, test, testSte, train1, valid1, test1,
				testSte1);
		printf("First Error (train/valid/test) = %f/%f/%f (%f)\n", train, valid,
				test, testSte);
		printf("Second Error (train/valid/test) = %f/%f/%f (%f)\n", train1,
				valid1, test1, testSte1);

		// MAE
		double mae_train, mae_valid, mae_test, mae_train1, mae_valid1,
				mae_test1;
		validMaeError(mae_train, mae_valid, mae_test, mae_train1, mae_valid1,
				mae_test1);
		printf("MAE: First Error (train/valid/test) = %f/%f/%f\n",
				mae_train, mae_valid, mae_test);
		printf("MAE: Second Error (train/valid/test) = %f/%f/%f\n",
				mae_train1, mae_valid1, mae_test1);

		if (valid < bestValid) {
			bestValid = valid;
			for (vector<vote*>::iterator it = corp->V->begin();
					it != corp->V->end(); it++)
				bestValidPredictions[*it] = prediction(*it, 1);
			if (test < bestTest)
				bestTest = test;
		}
		if (valid1 < bestValid1) {
			bestValid1 = valid1;
			for (vector<vote*>::iterator it = corp1->V->begin();
					it != corp1->V->end(); it++)
				bestValidPredictions1[*it] = prediction(*it, 2);
			if (test1 < bestTest1)
				bestTest1 = test1;
		}
		//MAE
		if (mae_valid < mae_bestValid) {
			mae_bestValid = mae_valid;
			if (mae_test < mae_bestTest)
				mae_bestTest = mae_test;
		}
		if (mae_valid1 < mae_bestValid1) {
			mae_bestValid1 = mae_valid1;
			if (mae_test1 < mae_bestTest1)
				mae_bestTest1 = mae_test1;
		}
		printf("#####################################################\n");
	}
	printf("First best test:%f, Second best test:%f\n", bestTest, bestTest1);
	printf("MAE: First best test:%f, Second best test:%f\n", mae_bestTest, mae_bestTest1);

}

int main(int argc, char** argv) {
	srand(0);

	if (argc < 2) {
		printf("An input file is required\n");
		exit(0);
	}

	double latentReg = 100;
	double latentReg1 = 100;
	double lambda = 3;
	double lambda1 = 3;
	int K = 15;
	double global_lambda = 0.1;
	//映射函数中的参数
	double sigma_square = 2.5;
	double gamma_map = 500;
	char* modelPath = "model.out";
	char* predictionPath = "predictions.out";

	if (argc == 8) {
		latentReg = atof(argv[3]);
		lambda = atof(argv[4]);
		global_lambda = atof(argv[5]);
		K = atoi(argv[6]);
		modelPath = argv[7];
		predictionPath = argv[8];
	}

	printf("First corpus = %s\n", argv[1]);
	printf("Second corpus/ = %s\n", argv[2]);
	printf("latentReg = %f\n", latentReg);
	printf("latentReg1 = %f\n", latentReg1);
	printf("lambda = %f\n", lambda);
	printf("lambda1 = %f\n", lambda1);
	printf("global_lambda = %f\n", global_lambda);
	printf("sigma_square = %f\n", sigma_square);
	printf("gamma_map = %f\n", gamma_map);
	printf("K = %d\n", K);

	printf("\nfirst corp:::::::::::");
	corpus corp(argv[1], 0); // first domain
	printf("second corp::::::::::::");
	corpus corp1(argv[2], 0); // second domain

	printf("start train::::::::::::\n");
	std::vector<pair<double, double> > rs;
	std::vector<pair<double, double> > d1;
	std::vector<pair<double, double> > d2;

	//对K值的测试 K=5/10/15/20
//	FILE* f = fopen_("K.out", "w");
//	for (int i = 0; i < 4; i++) {
//		topicCorpus ec(&corp, &corp1, K, // K
//				latentReg, latentReg1, // latent topic regularizer
//				lambda, lambda1, // lambda miu
//				global_lambda, sigma_square, gamma_map,true);
//		ec.train(40, 30); //50
//		rs.push_back(make_pair(ec.bestTest, ec.bestTest1));
//		d1.push_back(make_pair(latentReg, lambda));
//		d2.push_back(make_pair(latentReg1, lambda1));
//		fprintf(f, "K:%d, MSE1:%f, MSE:%f\n", K, ec.bestTest, ec.bestTest1);
//		K += 5;
//	}
//	fclose(f);

//	FILE* f = fopen_("latentReg_lambda.out", "w");
//	fprintf(f, "latentReg	lambda	  MSE	|	latentReg1	lambda1	  MSE1\n");
//	for (int i = 0; i < 5; i++) {
//		for (int j = 0; j < 5; j++) {
//			printf("\n\n::::::::::::::::::::迭代：%d,%d开始:::::::::::::::::::\n\n",
//					i, j);
			topicCorpus ec(&corp, &corp1, K, // K
					latentReg, latentReg1, // latent topic regularizer
					lambda, lambda1, // lambda miu
					global_lambda, sigma_square, gamma_map, true);
			ec.train(40, 40); //50
//			rs.push_back(make_pair(ec.bestTest, ec.bestTest1));
//			d1.push_back(make_pair(latentReg, lambda));
//			d2.push_back(make_pair(latentReg1, lambda1));
//			fprintf(f, "%f	%f	  %f	|	%f	%f	  %f\n", latentReg, lambda,
//					ec.bestTest, latentReg1, lambda1, ec.bestTest1);
//			lambda *= 10;
//			lambda1 *= 10;
//		}
//		latentReg *= 10;
//		latentReg1 *= 10;
//		lambda = 0.01;
//		lambda1 = 0.01;
//	}
//	fclose(f);
//	printf("end train::::::::::::\n");
//
//	printf("迭代结果：\n");
//	for (int i = 0; i < rs.size(); i++) {
//		printf("latentReg:%f,lambda:%f::first best MSE:%f\n", d1[i].first,
//				d1[i].second, rs[i].first);
//		printf("latentReg1:%f,lambda1:%f::second best MSE %f\n\n", d2[i].first,
//				d2[i].second, rs[i].second);
//	}

	// ec.save(modelPath, predictionPath);

	return 0;
}
