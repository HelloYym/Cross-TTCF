#include "common.hpp"

class topicCorpus {
public:
	topicCorpus(corpus* corp, corpus* corp1, // The corpus
			int K, // The number of latent factors
			double latentReg, double latentReg1, // Parameter regularizer used by the "standard" recommender system
			double lambda, double lambda1, // Word regularizer used by HFT
			double global_lambda, double sigma_square, double gamma_map, bool loadData) :
			corp(corp), corp1(corp1), K(K), latentReg(latentReg), latentReg1(
					latentReg1), lambda(lambda), lambda1(lambda), global_lambda(
					global_lambda), sigma_square(sigma_square), gamma_map(
					gamma_map) {
		srand(0);

		nUsers = corp->nUsers;
		nBeers = corp->nBeers;
		nWords = corp->nWords;
		//sd
		nUsers1 = corp1->nUsers;
		nBeers1 = corp1->nBeers;
		nWords1 = corp1->nWords;

		votesPerUser = new std::vector<vote*>[nUsers];	// vector数组
		votesPerBeer = new std::vector<vote*>[nBeers];
		trainVotesPerUser = new std::vector<vote*>[nUsers];
		trainVotesPerBeer = new std::vector<vote*>[nBeers];
		//sd
		votesPerUser1 = new std::vector<vote*>[nUsers1];	// vector数组
		votesPerBeer1 = new std::vector<vote*>[nBeers1];
		trainVotesPerUser1 = new std::vector<vote*>[nUsers1];
		trainVotesPerBeer1 = new std::vector<vote*>[nBeers1];

		// 初始化映射函数参数
		nCommon = 0;	// 找出两个域都活跃的用户
		for (int i = 0; i < nUsers; i++) {
			std::string userId = corp->rUserIds[i];
			if (corp1->userIds.find(userId) != corp1->userIds.end()) {
				nCommon++;
			}
		}
		commonUserId = new pair<int, int> [nCommon];
		int kk = 0;
		for (int i = 0; i < nUsers; i++) {
			std::string userId = corp->rUserIds[i];
			if (corp1->userIds.find(userId) != corp1->userIds.end()) {
				commonUserId[kk++] = (make_pair(i, corp1->userIds[userId]));
			}
		}
		printf("Common users Number: %d\n\n", nCommon);

		K_map = gsl_matrix_alloc(nCommon + 1, nCommon + 1);
		gsl_matrix_set_all(K_map, 1);
		gsl_matrix_set(K_map, 0, 0, 0);
		K_map1 = gsl_matrix_alloc(nCommon + 1, nCommon + 1);
		gsl_matrix_set_all(K_map1, 1);
		gsl_matrix_set(K_map1, 0, 0, 0);

		ALPHA = gsl_matrix_alloc(nCommon, K);
		ALPHA1 = gsl_matrix_alloc(nCommon, K);
		gsl_matrix_set_identity(ALPHA);
		gsl_matrix_set_identity(ALPHA1);

		BETA = gsl_vector_alloc(nCommon);
		BETA1 = gsl_vector_alloc(nCommon);
		gsl_vector_set_all(BETA, 0.000001);
		gsl_vector_set_all(BETA1, 0.000001);

		// 初始化用户评价项目
		for (std::vector<vote*>::iterator it = corp->V->begin();
				it != corp->V->end(); it++) {
			vote* vi = *it;
			votesPerUser[vi->user].push_back(vi);
		}
		//sd
		for (std::vector<vote*>::iterator it = corp1->V->begin();
				it != corp1->V->end(); it++) {
			vote* vi = *it;
			votesPerUser1[vi->user].push_back(vi);
		}

		// 初始化物品评价项
		for (int user = 0; user < nUsers; user++)
			for (std::vector<vote*>::iterator it = votesPerUser[user].begin();
					it != votesPerUser[user].end(); it++) {
				vote* vi = *it;
				votesPerBeer[vi->item].push_back(vi);
			}
		//sd
		for (int user = 0; user < nUsers1; user++)
			for (std::vector<vote*>::iterator it = votesPerUser1[user].begin();
					it != votesPerUser1[user].end(); it++) {
				vote* vi = *it;
				votesPerBeer1[vi->item].push_back(vi);
			}

		// 加载数据集部分
		if(loadData){
			FILE* ftr = fopen_("train.in", "w");
			FILE* fva = fopen_("valid.in", "w");
			FILE* fte = fopen_("test.in", "w");
			FILE* ftr1 = fopen_("train1.in", "w");
			FILE* fva1 = fopen_("valid1.in", "w");
			FILE* fte1 = fopen_("test1.in", "w");
			double testFraction = 0.1; //测试部分
			if (corp->V->size() > 2400000) {
				double trainFraction = 2000000.0 / corp->V->size();
				testFraction = (1.0 - trainFraction) / 2;
			}
			// 划分训练集、校验及和测试集
			for (std::vector<vote*>::iterator it = corp->V->begin();
					it != corp->V->end(); it++) {
				vote* v = *it;
				double r = rand() * 1.0 / RAND_MAX;
				if (r < testFraction) { // 10%
					testVotes.insert(*it);
					writeData(fte, v);
				} else if (r < 2 * testFraction) {// 10%
					validVotes.push_back(*it);
					writeData(fva, v);
				}
				else {							// 80%
					trainVotes.push_back(*it);
					trainVotesPerUser[(*it)->user].push_back(*it);
					trainVotesPerBeer[(*it)->item].push_back(*it);
					if (nTrainingPerUser.find((*it)->user)
							== nTrainingPerUser.end())
						nTrainingPerUser[(*it)->user] = 0;
					if (nTrainingPerBeer.find((*it)->item)
							== nTrainingPerBeer.end())
						nTrainingPerBeer[(*it)->item] = 0;
					nTrainingPerUser[(*it)->user]++;
					nTrainingPerBeer[(*it)->item]++;
					writeData(ftr, v);
				}
			}
			//sd
			for (std::vector<vote*>::iterator it = corp1->V->begin();
					it != corp1->V->end(); it++) {
				double r = rand() * 1.0 / RAND_MAX;
				vote* v1 = *it;
				if (r < testFraction) { // 10%
					testVotes1.insert(*it);
					writeData(fte1, v1);
				} else if (r < 2 * testFraction) { // 10%
					validVotes1.push_back(*it);
					writeData(fva1, v1);
				} else {							// 80%
					trainVotes1.push_back(*it);
					trainVotesPerUser1[(*it)->user].push_back(*it);
					trainVotesPerBeer1[(*it)->item].push_back(*it);
					if (nTrainingPerUser1.find((*it)->user)
							== nTrainingPerUser1.end())
						nTrainingPerUser1[(*it)->user] = 0;
					if (nTrainingPerBeer1.find((*it)->item)
							== nTrainingPerBeer1.end())
						nTrainingPerBeer1[(*it)->item] = 0;
					nTrainingPerUser1[(*it)->user]++;
					nTrainingPerBeer1[(*it)->item]++;
					writeData(ftr1, v1);
				}
			}
			fclose(ftr);
			fclose(fte);
			fclose(fva);
			fclose(ftr1);
			fclose(fte1);
			fclose(fva1);
		}else{
			loadVotes_train("train.in", trainVotes, 1);
			loadVotes_set("test.in", testVotes);
			loadVotes("valid.in", validVotes);
			loadVotes_train("train1.in", trainVotes1, 2);
			loadVotes_set("test1.in", testVotes1);
			loadVotes("valid1.in", validVotes1);
		}

		std::vector<vote*> remove; // 训练集中未出现的用户和物品删除
		for (std::set<vote*>::iterator it = testVotes.begin();
				it != testVotes.end(); it++) {
			if (nTrainingPerUser.find((*it)->user) == nTrainingPerUser.end())
				remove.push_back(*it);
			else if (nTrainingPerBeer.find((*it)->item)
					== nTrainingPerBeer.end())
				remove.push_back(*it);
		}
		for (std::vector<vote*>::iterator it = remove.begin();
				it != remove.end(); it++) {
			// Uncomment the line below to ignore (at testing time) users/items that don't appear in the training set
			//testVotes.erase(*it);
		}
		//sd
		remove.clear();
		for (std::set<vote*>::iterator it = testVotes1.begin();
				it != testVotes1.end(); it++) {
			if (nTrainingPerUser1.find((*it)->user) == nTrainingPerUser1.end())
				remove.push_back(*it);
			else if (nTrainingPerBeer1.find((*it)->item)
					== nTrainingPerBeer1.end())
				remove.push_back(*it);
		}
		for (std::vector<vote*>::iterator it = remove.begin();
				it != remove.end(); it++) {
			// Uncomment the line below to ignore (at testing time) users/items that don't appear in the training set
			// testVotes.erase(*it);
		}

		// total number of parameters
		NW = 1 + 1 + 1 + 1 + (K + 1) * (nUsers + nBeers + nUsers1 + nBeers1)
				+ K * nWords + K * nWords1;

		// Initialize parameters and latent variables
		// Zero all weights
		W = new double[NW];
		for (int i = 0; i < NW; i++)
			W[i] = 0;
		// 将线性数组映射到不同的参数上
		getG(W, &alpha, &kappa, &alpha1, &kappa1, &beta_user, &beta_beer,
				&beta_user1, &beta_beer1, &gamma_user, &gamma_beer, &topicWords,
				&gamma_user1, &gamma_beer1, &topicWords1, true);

		// Set alpha to the average
		for (std::vector<vote*>::iterator vi = trainVotes.begin();
				vi != trainVotes.end(); vi++) {
			*alpha += (*vi)->value;
		}
		*alpha /= trainVotes.size();
		// sd
		for (std::vector<vote*>::iterator vi = trainVotes1.begin();
				vi != trainVotes1.end(); vi++) {
			*alpha1 += (*vi)->value;
		}
		*alpha1 /= trainVotes1.size();

		double train, valid, test, testSte, train1, valid1, test1, testSte1;
		validTestError(train, valid, test, testSte, train1, valid1, test1,
				testSte1);
		printf(
				"First Error w/ offset term only (train/valid/test) = %f/%f/%f (%f)\n",
				train, valid, test, testSte);
		printf(
				"Second Error w/ offset term only (train/valid/test) = %f/%f/%f (%f)\n",
				train1, valid1, test1, testSte1);

		// Set beta to user and product offsets 用户和物品
		for (std::vector<vote*>::iterator vi = trainVotes.begin();
				vi != trainVotes.end(); vi++) {
			vote* v = *vi;
			beta_user[v->user] += v->value - *alpha;
			beta_beer[v->item] += v->value - *alpha;
		}
		for (int u = 0; u < nUsers; u++)
			beta_user[u] /= votesPerUser[u].size();
		for (int b = 0; b < nBeers; b++)
			beta_beer[b] /= votesPerBeer[b].size();
		//sd
		for (std::vector<vote*>::iterator vi = trainVotes1.begin();
				vi != trainVotes1.end(); vi++) {
			vote* v = *vi;
			beta_user1[v->user] += v->value - *alpha1;
			beta_beer1[v->item] += v->value - *alpha1;
		}
		for (int u = 0; u < nUsers1; u++)
			beta_user1[u] /= votesPerUser1[u].size();
		for (int b = 0; b < nBeers1; b++)
			beta_beer1[b] /= votesPerBeer1[b].size();

		validTestError(train, valid, test, testSte, train1, valid1, test1,
				testSte1);
		printf(
				"\nError w/ offset and bias (train/valid/test) = %f/%f/%f (%f)\n",
				train, valid, test, testSte);
		printf(
				"Second Error w/ offset term only (train/valid/test) = %f/%f/%f (%f)\n",
				train1, valid1, test1, testSte1);

		// 初始化映射函数参数
		//updateMapPara();

		// Actually the model works better if we initialize none of these terms
		if (lambda > 0) {
			*alpha = 0;
			for (int u = 0; u < nUsers; u++)
				beta_user[u] = 0;
			for (int b = 0; b < nBeers; b++)
				beta_beer[b] = 0;
		}
		//sd
		if (lambda1 > 0) {
			*alpha1 = 0;
			for (int u = 0; u < nUsers1; u++)
				beta_user1[u] = 0;
			for (int b = 0; b < nBeers1; b++)
				beta_beer1[b] = 0;
		}

		wordTopicCounts = new int*[nWords];
		for (int w = 0; w < nWords; w++) {
			wordTopicCounts[w] = new int[K];
			for (int k = 0; k < K; k++)
				wordTopicCounts[w][k] = 0;
		}
		//sd
		wordTopicCounts1 = new int*[nWords1];
		for (int w = 0; w < nWords1; w++) {
			wordTopicCounts1[w] = new int[K];
			for (int k = 0; k < K; k++)
				wordTopicCounts1[w][k] = 0;
		}

		// Generate random topic assignments
		topicCounts = new long long[K];
		for (int k = 0; k < K; k++)
			topicCounts[k] = 0;
		beerTopicCounts = new int*[nBeers];
		beerWords = new int[nBeers];
		for (int b = 0; b < nBeers; b++) {
			beerTopicCounts[b] = new int[K];
			for (int k = 0; k < K; k++)
				beerTopicCounts[b][k] = 0;
			beerWords[b] = 0;
		}
		//sd
		topicCounts1 = new long long[K];
		for (int k = 0; k < K; k++)
			topicCounts1[k] = 0;
		beerTopicCounts1 = new int*[nBeers1];
		beerWords1 = new int[nBeers1];
		for (int b = 0; b < nBeers1; b++) {
			beerTopicCounts1[b] = new int[K];
			for (int k = 0; k < K; k++)
				beerTopicCounts1[b][k] = 0;
			beerWords1[b] = 0;
		}

		for (std::vector<vote*>::iterator vi = trainVotes.begin();
				vi != trainVotes.end(); vi++) {
			vote* v = *vi;
			wordTopics[v] = new int[v->words.size()];
			beerWords[(*vi)->item] += v->words.size();

			for (int wp = 0; wp < (int) v->words.size(); wp++) {
				int wi = v->words[wp];
				int t = rand() % K; // 随机给出初始值

				wordTopics[v][wp] = t;
				beerTopicCounts[(*vi)->item][t]++;
				wordTopicCounts[wi][t]++;
				topicCounts[t]++;
			}
		}
		//sd
		for (std::vector<vote*>::iterator vi = trainVotes1.begin();
				vi != trainVotes1.end(); vi++) {
			vote* v = *vi;
			wordTopics1[v] = new int[v->words.size()];
			beerWords1[(*vi)->item] += v->words.size();

			for (int wp = 0; wp < (int) v->words.size(); wp++) {
				int wi = v->words[wp];
				int t = rand() % K; // 随机给出初始值

				wordTopics1[v][wp] = t;
				beerTopicCounts1[(*vi)->item][t]++;
				wordTopicCounts1[wi][t]++;
				topicCounts1[t]++;
			}
		}

		// Initialize the background word frequency
		totalWords = 0;
		backgroundWords = new double[nWords];
		for (int w = 0; w < nWords; w++)
			backgroundWords[w] = 0;
		for (std::vector<vote*>::iterator vi = trainVotes.begin();
				vi != trainVotes.end(); vi++) {
			for (std::vector<int>::iterator it = (*vi)->words.begin();
					it != (*vi)->words.end(); it++) {
				totalWords++;
				backgroundWords[*it]++;
			}
		}
		for (int w = 0; w < nWords; w++)
			backgroundWords[w] /= totalWords;
		//sd
		totalWords1 = 0;
		backgroundWords1 = new double[nWords1];
		for (int w = 0; w < nWords1; w++)
			backgroundWords1[w] = 0;
		for (std::vector<vote*>::iterator vi = trainVotes1.begin();
				vi != trainVotes1.end(); vi++) {
			for (std::vector<int>::iterator it = (*vi)->words.begin();
					it != (*vi)->words.end(); it++) {
				totalWords1++;
				backgroundWords1[*it]++;
			}
		}
		for (int w = 0; w < nWords1; w++)
			backgroundWords1[w] /= totalWords1;

		if (lambda == 0) {
			for (int u = 0; u < nUsers; u++) {
				if (nTrainingPerUser.find(u) == nTrainingPerUser.end())
					continue;
				for (int k = 0; k < K; k++)
					gamma_user[u][k] = rand() * 1.0 / RAND_MAX;
			}
			for (int b = 0; b < nBeers; b++) {
				if (nTrainingPerBeer.find(b) == nTrainingPerBeer.end())
					continue;
				for (int k = 0; k < K; k++)
					gamma_beer[b][k] = rand() * 1.0 / RAND_MAX;
			}
		} else {
			for (int w = 0; w < nWords; w++)
				for (int k = 0; k < K; k++)
					topicWords[w][k] = 0;
		}
		//sd
		if (lambda1 == 0) {
			for (int u = 0; u < nUsers1; u++) {
				if (nTrainingPerUser1.find(u) == nTrainingPerUser1.end())
					continue;
				for (int k = 0; k < K; k++)
					gamma_user1[u][k] = rand() * 1.0 / RAND_MAX;
			}
			for (int b = 0; b < nBeers1; b++) {
				if (nTrainingPerBeer1.find(b) == nTrainingPerBeer1.end())
					continue;
				for (int k = 0; k < K; k++)
					gamma_beer1[b][k] = rand() * 1.0 / RAND_MAX;
			}
		} else {
			for (int w = 0; w < nWords1; w++)
				for (int k = 0; k < K; k++)
					topicWords1[w][k] = 0;
		}

		normalizeWordWeights();
		if (lambda > 0 || lambda1 > 0)
			updateTopics(true);

		*kappa = 1.0;
		*kappa1 = 1.0;
		flag = false;
	}

	~topicCorpus() {
		delete[] votesPerBeer;
		delete[] votesPerUser;
		delete[] trainVotesPerBeer;
		delete[] trainVotesPerUser;
		//sd
		delete[] votesPerBeer1;
		delete[] votesPerUser1;
		delete[] trainVotesPerBeer1;
		delete[] trainVotesPerUser1;

		for (int w = 0; w < nWords; w++)
			delete[] wordTopicCounts[w];
		delete[] wordTopicCounts;
		//sd
		for (int w = 0; w < nWords1; w++)
			delete[] wordTopicCounts1[w];
		delete[] wordTopicCounts1;

		for (int b = 0; b < nBeers; b++)
			delete[] beerTopicCounts[b];
		delete[] beerTopicCounts;
		delete[] beerWords;
		delete[] topicCounts;
		//sd
		for (int b = 0; b < nBeers1; b++)
			delete[] beerTopicCounts1[b];
		delete[] beerTopicCounts1;
		delete[] beerWords1;
		delete[] topicCounts1;

		delete[] backgroundWords;
		delete[] backgroundWords1;

		for (std::vector<vote*>::iterator vi = trainVotes.begin();
				vi != trainVotes.end(); vi++) {
			delete[] wordTopics[*vi];
		}
		//sd
		for (std::vector<vote*>::iterator vi = trainVotes1.begin();
				vi != trainVotes1.end(); vi++) {
			delete[] wordTopics1[*vi];
		}

		clearG(&alpha, &kappa, &alpha1, &kappa1, &beta_user, &beta_beer,
				&beta_user1, &beta_beer1, &gamma_user, &gamma_beer, &topicWords,
				&gamma_user1, &gamma_beer1, &topicWords1);
		delete[] W;

		// gsl free
		gsl_matrix_free(ALPHA);
		gsl_matrix_free(ALPHA1);
		gsl_matrix_free(K_map);
		gsl_matrix_free(K_map1);
		gsl_vector_free(BETA);
		gsl_vector_free(BETA1);
	}

	double prediction(vote* vi, int domain);

	void dl(double* grad);
	void train(int emIterations, int gradIterations);
	double lsq(void);
	void validTestError(double& train, double& valid, double& test,
			double& testSte, double& train1, double& valid1, double& test1,
			double& testSte1);
	void validMaeError(double& train, double& valid, double& test,
			double& train1, double& valid1, double& test1);
	void normalizeWordWeights(void);
	void save(char* modelPath, char* predictionPath);
	void writeData(FILE* f, vote* v);
	void loadVotes(std::string fn, std::vector<vote*> V);
	void loadVotes_set(std::string fn, std::set<vote*> V);
	void loadVotes_train(std::string fn, std::vector<vote*> V, int domain);

	corpus* corp;
	corpus* corp1;

	// Votes from the training, validation, and test sets (用户的评分)
	std::vector<vote*> trainVotes;
	std::vector<vote*> validVotes;
	std::set<vote*> testVotes;
	// sd
	std::vector<vote*> trainVotes1;
	std::vector<vote*> validVotes1;
	std::set<vote*> testVotes1;


	std::map<vote*, double> bestValidPredictions;
	std::map<vote*, double> bestValidPredictions1;

	std::vector<vote*>* votesPerBeer; // Vector of votes for each item
	std::vector<vote*>* votesPerUser; // Vector of votes for each user
	std::vector<vote*>* trainVotesPerBeer; // Same as above, but only votes from the training set
	std::vector<vote*>* trainVotesPerUser;
	//sd
	std::vector<vote*>* votesPerBeer1; // Vector of votes for each item
	std::vector<vote*>* votesPerUser1; // Vector of votes for each user
	std::vector<vote*>* trainVotesPerBeer1; // Same as above, but only votes from the training set
	std::vector<vote*>* trainVotesPerUser1;

	int getG(double* g, double** alpha, double** kappa, double** alpha1,
			double** kappa1, double** beta_user, double** beta_beer,
			double** beta_user1, double** beta_beer1, double*** gamma_user,
			double*** gamma_beer, double*** topicWords, double*** gamma_user1,
			double*** gamma_beer1, double*** topicWords1, bool init);
	void clearG(double** alpha, double** kappa, double** alpha1,
			double** kappa1, double** beta_user, double** beta_beer,
			double** beta_user1, double** beta_beer1, double*** gamma_user,
			double*** gamma_beer, double*** topicWords, double*** gamma_user1,
			double*** gamma_beer1, double*** topicWords1);

	void wordZ(double* res, int domain);
	void topicZ(int beer, double& res, int domain);
	void updateTopics(bool sample);
	void topWords();
	void updateMapPara();	// 更新映射函数参数
	double mapFunErr(int u, int i, int domain);
	double dmapFunErr(int u, int i, int domain);
	double computeK(int u1, int u2, int domain);
	void setAlphaBeta(gsl_vector* x, int i, int domain);
	void matrix_vector_solve(const gsl_matrix* m, const gsl_vector* b,
			gsl_vector* v);

	// cross domain parameters
	double sigma_square;	// 映射函数中的sigma超参数
	double gamma_map;
	//f
	gsl_matrix* ALPHA;
	gsl_vector* BETA; // 映射函数中的beta参数
	gsl_matrix* K_map;
	//g
	gsl_matrix* ALPHA1;
	gsl_vector* BETA1; // 映射函数中的beta参数
	gsl_matrix* K_map1;
//	std::vector<std::pair<int, int> > commonUserId; // 记录common用户，<first, second>
	pair<int, int>* commonUserId;
	// Model parameters
	double* alpha; // Offset parameter
	double* kappa; // "peakiness" parameter
	double* beta_user; // User offset parameters
	double* beta_beer; // Item offset parameters
	double** gamma_user; // User latent factors
	double** gamma_beer; // Item latent factors
	//sd
	double* alpha1; // Offset parameter
	double* kappa1; // "peakiness" parameter
	double* beta_user1; // User offset parameters
	double* beta_beer1; // Item offset parameters
	double** gamma_user1; // User latent factors
	double** gamma_beer1; // Item latent factors
	double bestTest;
	double bestTest1;
	double mae_bestTest;
	double mae_bestTest1;

	double* W; // Contiguous version of all parameters, i.e., a flat vector containing all parameters in order (useful for lbfgs)

	double** topicWords; // Weights each word in each topic
	double* backgroundWords; // "background" weight, so that each word has average weight zero across all topics
	// Latent variables
	std::map<vote*, int*> wordTopics;
	//sd
	double** topicWords1; // Weights each word in each topic
	double* backgroundWords1; // "background" weight, so that each word has average weight zero across all topics
	// Latent variables
	std::map<vote*, int*> wordTopics1;

	// Counters
	int** beerTopicCounts; // How many times does each topic occur for each product?
	int* beerWords; // Number of words in each "document"
	long long* topicCounts; // How many times does each topic occur?
	int** wordTopicCounts; // How many times does this topic occur for this word?
	long long totalWords; // How many words are there?
	//sd
	int** beerTopicCounts1; // How many times does each topic occur for each product?
	int* beerWords1; // Number of words in each "document"
	long long* topicCounts1; // How many times does each topic occur?
	int** wordTopicCounts1; // How many times does this topic occur for this word?
	long long totalWords1; // How many words are there?

	int NW;
	int K;

	double latentReg;
	double latentReg1;
	double lambda;
	double lambda1;
	double global_lambda;

	std::map<int, int> nTrainingPerUser; // Number of training items for each user
	std::map<int, int> nTrainingPerBeer; // and item
	//sd
	std::map<int, int> nTrainingPerUser1; // Number of training items for each user
	std::map<int, int> nTrainingPerBeer1; // and item

	int nUsers; // Number of users
	int nBeers; // Number of items
	int nWords; // Number of words
	//sd
	int nUsers1; // Number of users
	int nBeers1; // Number of items
	int nWords1; // Number of words

	// cross
	int nCommon; // Number of common users
	bool flag;
};
